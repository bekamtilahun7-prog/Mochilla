import { Link } from "react-router";
import {
  MessageSquare,
  FileQuestion,
  CreditCard,
  ClipboardCheck,
  TrendingUp,
  Flame,
  Target,
  AlertCircle,
  BookOpen,
  Clock,
} from "lucide-react";

export function Dashboard() {
  return (
    <div className="p-8 space-y-8">
      {/* Welcome Header */}
      <div>
        <h1 className="text-3xl font-bold text-foreground">
          Welcome back, Sarah! 👋
        </h1>
        <p className="text-muted-foreground mt-2">
          Ready to continue your learning journey?
        </p>
      </div>

      {/* Study Streak Widget */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card rounded-2xl p-6 shadow-sm border border-border transition-colors duration-300">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#F59E0B] to-[#EF4444] rounded-xl flex items-center justify-center">
              <Flame className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">12 Days</p>
              <p className="text-sm text-muted-foreground">Study Streak</p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-2xl p-6 shadow-sm border border-border transition-colors duration-300">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-secondary to-accent rounded-xl flex items-center justify-center">
              <Target className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">87%</p>
              <p className="text-sm text-muted-foreground">Overall Progress</p>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-2xl p-6 shadow-sm border border-border transition-colors duration-300">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-[#2ED3B7] to-[#22C55E] rounded-xl flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-2xl font-bold text-foreground">24</p>
              <p className="text-sm text-muted-foreground">Topics Mastered</p>
            </div>
          </div>
        </div>
      </div>

      {/* Continue Learning */}
      <div className="bg-card rounded-2xl p-6 shadow-sm border border-border transition-colors duration-300">
        <h2 className="text-xl font-bold text-foreground mb-4">
          Continue Learning
        </h2>
        <div className="space-y-4">
          <div className="flex items-center gap-4 p-4 bg-muted rounded-xl hover:opacity-80 transition-all cursor-pointer">
            <div className="w-12 h-12 bg-accent rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">
                Calculus II - Integration Techniques
              </h3>
              <p className="text-sm text-muted-foreground">Last studied 2 hours ago</p>
            </div>
            <div className="text-right">
              <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-accent"
                  style={{ width: "65%" }}
                ></div>
              </div>
              <p className="text-xs text-muted-foreground mt-1">65% complete</p>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 bg-muted rounded-xl hover:opacity-80 transition-all cursor-pointer">
            <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">
                World History - Renaissance Period
              </h3>
              <p className="text-sm text-muted-foreground">Last studied yesterday</p>
            </div>
            <div className="text-right">
              <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-secondary"
                  style={{ width: "42%" }}
                ></div>
              </div>
              <p className="text-xs text-muted-foreground mt-1">42% complete</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-xl font-bold text-foreground mb-4">Quick Actions</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link
            to="/ask-mochila"
            className="bg-gradient-to-br from-accent to-accent/80 rounded-2xl p-6 text-white hover:shadow-lg transition-all hover:scale-105"
          >
            <MessageSquare className="w-8 h-8 mb-3" />
            <h3 className="font-semibold mb-1">Ask MOCHILA</h3>
            <p className="text-sm text-white/80">Get instant answers</p>
          </Link>

          <Link
            to="/quiz"
            className="bg-gradient-to-br from-secondary to-secondary/80 rounded-2xl p-6 text-white hover:shadow-lg transition-all hover:scale-105"
          >
            <FileQuestion className="w-8 h-8 mb-3" />
            <h3 className="font-semibold mb-1">Start Quiz</h3>
            <p className="text-sm text-white/80">Test your knowledge</p>
          </Link>

          <Link
            to="/flashcards"
            className="bg-gradient-to-br from-[#2ED3B7] to-[#4EE3C7] rounded-2xl p-6 text-white hover:shadow-lg transition-all hover:scale-105"
          >
            <CreditCard className="w-8 h-8 mb-3" />
            <h3 className="font-semibold mb-1">Flashcards</h3>
            <p className="text-sm text-white/80">Review concepts</p>
          </Link>

          <Link
            to="/exam"
            className="bg-gradient-to-br from-[#F59E0B] to-[#FBBF24] rounded-2xl p-6 text-white hover:shadow-lg transition-all hover:scale-105"
          >
            <ClipboardCheck className="w-8 h-8 mb-3" />
            <h3 className="font-semibold mb-1">Exam Mode</h3>
            <p className="text-sm text-white/80">Full practice test</p>
          </Link>
        </div>
      </div>

      {/* Progress Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card rounded-2xl p-6 shadow-sm border border-border transition-colors duration-300">
          <h2 className="text-xl font-bold text-foreground mb-4">
            Weak Areas to Focus On
          </h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-destructive/10 rounded-lg border border-destructive/20">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-destructive" />
                <span className="font-medium text-foreground">
                  Organic Chemistry
                </span>
              </div>
              <span className="text-sm text-destructive font-semibold">45%</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-destructive/10 rounded-lg border border-destructive/20">
              <div className="flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-destructive" />
                <span className="font-medium text-foreground">
                  Linear Algebra
                </span>
              </div>
              <span className="text-sm text-destructive font-semibold">52%</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-[#F59E0B]/10 rounded-lg border border-[#F59E0B]/20">
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-[#F59E0B]" />
                <span className="font-medium text-foreground">
                  Quantum Physics
                </span>
              </div>
              <span className="text-sm text-[#F59E0B] font-semibold">68%</span>
            </div>
          </div>
        </div>

        <div className="bg-card rounded-2xl p-6 shadow-sm border border-border transition-colors duration-300">
          <h2 className="text-xl font-bold text-foreground mb-4">
            Recent Activity
          </h2>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <FileQuestion className="w-4 h-4 text-accent" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">
                  Completed "Calculus Quiz"
                </p>
                <p className="text-xs text-muted-foreground">Score: 92% · 2 hours ago</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-[#2ED3B7]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <CreditCard className="w-4 h-4 text-[#2ED3B7]" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">
                  Reviewed 45 flashcards
                </p>
                <p className="text-xs text-muted-foreground">Chemistry · 5 hours ago</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-8 h-8 bg-secondary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MessageSquare className="w-4 h-4 text-secondary" />
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">
                  Asked MOCHILA about derivatives
                </p>
                <p className="text-xs text-muted-foreground">Yesterday</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}