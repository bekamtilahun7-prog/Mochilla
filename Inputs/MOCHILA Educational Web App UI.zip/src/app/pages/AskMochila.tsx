import { useState } from "react";
import { Send, Sparkles, Search, Plus, FileText } from "lucide-react";

const mockConversations = [
  { id: 1, title: "Calculus Integration Help", timestamp: "Today" },
  { id: 2, title: "World History Essay Tips", timestamp: "Yesterday" },
  { id: 3, title: "Organic Chemistry Reactions", timestamp: "2 days ago" },
];

const mockMessages = [
  {
    id: 1,
    type: "user",
    content: "Can you explain integration by parts?",
    timestamp: "10:23 AM",
  },
  {
    id: 2,
    type: "ai",
    content:
      "Integration by parts is a technique used to integrate products of functions. It's based on the product rule for differentiation.\n\nThe formula is: ∫u dv = uv - ∫v du\n\nHere's how to use it:\n1. Choose u and dv from your integral\n2. Differentiate u to get du\n3. Integrate dv to get v\n4. Apply the formula\n\nWould you like me to walk through an example?",
    timestamp: "10:23 AM",
    notes: [
      "Integration by parts formula: ∫u dv = uv - ∫v du",
      "Choose u using LIATE rule (Logarithmic, Inverse trig, Algebraic, Trig, Exponential)",
      "Best for products of different function types",
    ],
  },
  {
    id: 3,
    type: "user",
    content: "Yes, please show me an example with ∫x·e^x dx",
    timestamp: "10:25 AM",
  },
  {
    id: 4,
    type: "ai",
    content:
      "Great example! Let's solve ∫x·e^x dx step by step:\n\nStep 1: Choose u and dv\n• Let u = x (algebraic function)\n• Let dv = e^x dx (exponential function)\n\nStep 2: Find du and v\n• du = dx\n• v = ∫e^x dx = e^x\n\nStep 3: Apply the formula\n∫x·e^x dx = x·e^x - ∫e^x dx\n          = x·e^x - e^x + C\n          = e^x(x - 1) + C\n\nThat's your final answer! Notice how we chose u = x because it becomes simpler when differentiated.",
    timestamp: "10:25 AM",
    notes: [
      "Example: ∫x·e^x dx",
      "Solution: e^x(x - 1) + C",
      "Key insight: Choose u that simplifies when differentiated",
    ],
  },
];

export function AskMochila() {
  const [message, setMessage] = useState("");

  return (
    <div className="flex h-[calc(100vh-4rem)]">
      {/* Left Panel - Chat History */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <button className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-[#7C5CFF] to-[#9D7FFF] text-white rounded-xl hover:shadow-lg transition-all">
            <Plus className="w-5 h-5" />
            New Conversation
          </button>
        </div>

        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Search conversations..."
              className="w-full pl-9 pr-3 py-2 bg-[#F7F9FC] border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-[#7C5CFF]"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          <div className="space-y-2">
            {mockConversations.map((conv) => (
              <button
                key={conv.id}
                className="w-full text-left p-3 rounded-xl hover:bg-[#EEF3FB] transition-colors"
              >
                <h3 className="font-medium text-[#1C1F2A] text-sm truncate">
                  {conv.title}
                </h3>
                <p className="text-xs text-[#6B7280] mt-1">{conv.timestamp}</p>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Center Panel - Chat Interface */}
      <div className="flex-1 flex flex-col bg-[#F7F9FC]">
        <div className="p-6 bg-white border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-[#7C5CFF] to-[#9D7FFF] rounded-xl flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-[#1C1F2A]">Ask MOCHILA</h2>
              <p className="text-sm text-[#6B7280]">
                Your AI study assistant is ready to help
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="max-w-3xl mx-auto space-y-6">
            {mockMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex ${
                  msg.type === "user" ? "justify-end" : "justify-start"
                }`}
              >
                <div
                  className={`max-w-[80%] ${
                    msg.type === "user"
                      ? "bg-[#4A90E2] text-white rounded-2xl rounded-br-sm"
                      : "bg-white border border-gray-200 rounded-2xl rounded-bl-sm"
                  } p-4`}
                >
                  {msg.type === "ai" && (
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-[#7C5CFF]" />
                      <span className="text-xs font-semibold text-[#7C5CFF]">
                        MOCHILA AI
                      </span>
                    </div>
                  )}
                  <p
                    className={`whitespace-pre-line ${
                      msg.type === "user" ? "text-white" : "text-[#1C1F2A]"
                    }`}
                  >
                    {msg.content}
                  </p>
                  <p
                    className={`text-xs mt-2 ${
                      msg.type === "user" ? "text-white/70" : "text-[#9CA3AF]"
                    }`}
                  >
                    {msg.timestamp}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-6 bg-white border-t border-gray-200">
          <div className="max-w-3xl mx-auto">
            <div className="flex gap-3">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Ask MOCHILA anything..."
                className="flex-1 px-4 py-3 bg-[#F7F9FC] border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#7C5CFF]"
              />
              <button className="px-6 py-3 bg-gradient-to-r from-[#7C5CFF] to-[#9D7FFF] text-white rounded-xl hover:shadow-lg transition-all flex items-center gap-2">
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - AI-Generated Notes */}
      <div className="w-80 bg-white border-l border-gray-200 overflow-y-auto">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center gap-2 mb-2">
            <FileText className="w-5 h-5 text-[#7C5CFF]" />
            <h3 className="font-bold text-[#1C1F2A]">Generated Notes</h3>
          </div>
          <p className="text-sm text-[#6B7280]">
            Auto-generated from your conversation
          </p>
        </div>

        <div className="p-6">
          <div className="space-y-4">
            <div>
              <h4 className="font-semibold text-[#1C1F2A] mb-3">
                Integration by Parts
              </h4>
              <div className="space-y-2">
                {mockMessages
                  .find((m) => m.id === 2)
                  ?.notes?.map((note, index) => (
                    <div
                      key={index}
                      className="p-3 bg-[#7C5CFF]/5 border border-[#7C5CFF]/20 rounded-lg"
                    >
                      <p className="text-sm text-[#1C1F2A]">{note}</p>
                    </div>
                  ))}
              </div>
            </div>

            <div>
              <h4 className="font-semibold text-[#1C1F2A] mb-3">
                Example Solution
              </h4>
              <div className="space-y-2">
                {mockMessages
                  .find((m) => m.id === 4)
                  ?.notes?.map((note, index) => (
                    <div
                      key={index}
                      className="p-3 bg-[#4A90E2]/5 border border-[#4A90E2]/20 rounded-lg"
                    >
                      <p className="text-sm text-[#1C1F2A]">{note}</p>
                    </div>
                  ))}
              </div>
            </div>

            <button className="w-full py-2 px-4 bg-gradient-to-r from-[#7C5CFF] to-[#9D7FFF] text-white rounded-lg hover:shadow-lg transition-all text-sm">
              Save to Notes Library
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
