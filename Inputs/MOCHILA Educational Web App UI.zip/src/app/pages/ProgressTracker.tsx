import {
  LineChart,
  Line,
  BarChart,
  Bar,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import { TrendingUp, Target, Award, Calendar as CalendarIcon } from "lucide-react";

const weeklyActivityData = [
  { day: "Mon", minutes: 45, quizzes: 2 },
  { day: "Tue", minutes: 60, quizzes: 3 },
  { day: "Wed", minutes: 30, quizzes: 1 },
  { day: "Thu", minutes: 75, quizzes: 4 },
  { day: "Fri", minutes: 50, quizzes: 2 },
  { day: "Sat", minutes: 90, quizzes: 5 },
  { day: "Sun", minutes: 40, quizzes: 2 },
];

const progressOverTime = [
  { week: "Week 1", score: 65 },
  { week: "Week 2", score: 72 },
  { week: "Week 3", score: 68 },
  { week: "Week 4", score: 78 },
  { week: "Week 5", score: 82 },
  { week: "Week 6", score: 87 },
];

const subjectPerformance = [
  { subject: "Calculus", score: 87 },
  { subject: "Chemistry", score: 72 },
  { subject: "History", score: 90 },
  { subject: "Physics", score: 68 },
  { subject: "Literature", score: 85 },
];

const streakCalendar = [
  [true, true, true, false, true, true, true],
  [true, true, false, true, true, true, true],
  [true, true, true, true, false, true, true],
  [true, false, true, true, true, true, false],
];

export function ProgressTracker() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-[#1C1F2A] mb-2">
          Progress Tracker
        </h1>
        <p className="text-[#6B7280]">
          Track your learning journey and celebrate your achievements
        </p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-gradient-to-br from-[#4A90E2] to-[#7C5CFF] rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-8 h-8" />
            <div>
              <p className="text-sm text-white/80">Average Score</p>
              <p className="text-3xl font-bold">82%</p>
            </div>
          </div>
          <p className="text-sm text-white/70">↑ 8% from last month</p>
        </div>

        <div className="bg-gradient-to-br from-[#2ED3B7] to-[#22C55E] rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-8 h-8" />
            <div>
              <p className="text-sm text-white/80">Study Hours</p>
              <p className="text-3xl font-bold">47h</p>
            </div>
          </div>
          <p className="text-sm text-white/70">This week</p>
        </div>

        <div className="bg-gradient-to-br from-[#F59E0B] to-[#EF4444] rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <Award className="w-8 h-8" />
            <div>
              <p className="text-sm text-white/80">Achievements</p>
              <p className="text-3xl font-bold">24</p>
            </div>
          </div>
          <p className="text-sm text-white/70">Badges earned</p>
        </div>

        <div className="bg-gradient-to-br from-[#7C5CFF] to-[#9D7FFF] rounded-2xl p-6 text-white">
          <div className="flex items-center gap-3 mb-2">
            <CalendarIcon className="w-8 h-8" />
            <div>
              <p className="text-sm text-white/80">Study Streak</p>
              <p className="text-3xl font-bold">12</p>
            </div>
          </div>
          <p className="text-sm text-white/70">Days in a row</p>
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Activity */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-[#1C1F2A] mb-6">
            Weekly Study Activity
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={weeklyActivityData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF3FB" />
              <XAxis dataKey="day" stroke="#6B7280" />
              <YAxis stroke="#6B7280" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "12px",
                }}
              />
              <Legend />
              <Bar dataKey="minutes" fill="#4A90E2" radius={[8, 8, 0, 0]} name="Minutes" />
              <Bar dataKey="quizzes" fill="#7C5CFF" radius={[8, 8, 0, 0]} name="Quizzes" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Progress Over Time */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-[#1C1F2A] mb-6">
            Score Progress
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={progressOverTime}>
              <CartesianGrid strokeDasharray="3 3" stroke="#EEF3FB" />
              <XAxis dataKey="week" stroke="#6B7280" />
              <YAxis stroke="#6B7280" domain={[0, 100]} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "12px",
                }}
              />
              <Line
                type="monotone"
                dataKey="score"
                stroke="#2ED3B7"
                strokeWidth={3}
                dot={{ fill: "#2ED3B7", r: 6 }}
                activeDot={{ r: 8 }}
                name="Average Score %"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Subject Performance Radar */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-[#1C1F2A] mb-6">
            Subject Performance
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart data={subjectPerformance}>
              <PolarGrid stroke="#EEF3FB" />
              <PolarAngleAxis dataKey="subject" stroke="#6B7280" />
              <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#6B7280" />
              <Radar
                name="Score"
                dataKey="score"
                stroke="#7C5CFF"
                fill="#7C5CFF"
                fillOpacity={0.6}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#FFFFFF",
                  border: "1px solid #E5E7EB",
                  borderRadius: "12px",
                }}
              />
            </RadarChart>
          </ResponsiveContainer>
        </div>

        {/* Study Streak Calendar */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h2 className="text-xl font-bold text-[#1C1F2A] mb-6">
            Study Streak Calendar
          </h2>
          <div className="space-y-4">
            <div className="grid grid-cols-7 gap-2 mb-2">
              {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                <div key={day} className="text-center text-xs text-[#6B7280] font-medium">
                  {day}
                </div>
              ))}
            </div>
            {streakCalendar.map((week, weekIndex) => (
              <div key={weekIndex} className="grid grid-cols-7 gap-2">
                {week.map((active, dayIndex) => (
                  <div
                    key={dayIndex}
                    className={`aspect-square rounded-lg ${
                      active
                        ? "bg-gradient-to-br from-[#2ED3B7] to-[#22C55E]"
                        : "bg-gray-100"
                    }`}
                  ></div>
                ))}
              </div>
            ))}
          </div>
          <div className="mt-6 flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-gradient-to-br from-[#2ED3B7] to-[#22C55E]"></div>
              <span className="text-[#6B7280]">Study day</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded bg-gray-100"></div>
              <span className="text-[#6B7280]">Missed day</span>
            </div>
          </div>
        </div>
      </div>

      {/* Achievements */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-[#1C1F2A] mb-6">
          Recent Achievements
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 bg-gradient-to-br from-[#F59E0B]/10 to-[#F59E0B]/5 border border-[#F59E0B]/20 rounded-xl text-center">
            <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-[#F59E0B] to-[#FBBF24] rounded-full flex items-center justify-center">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-[#1C1F2A] text-sm mb-1">
              First Quiz Ace
            </h3>
            <p className="text-xs text-[#6B7280]">Scored 100% on a quiz</p>
          </div>

          <div className="p-4 bg-gradient-to-br from-[#7C5CFF]/10 to-[#7C5CFF]/5 border border-[#7C5CFF]/20 rounded-xl text-center">
            <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-[#7C5CFF] to-[#9D7FFF] rounded-full flex items-center justify-center">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-[#1C1F2A] text-sm mb-1">
              Study Warrior
            </h3>
            <p className="text-xs text-[#6B7280]">10 day streak</p>
          </div>

          <div className="p-4 bg-gradient-to-br from-[#2ED3B7]/10 to-[#2ED3B7]/5 border border-[#2ED3B7]/20 rounded-xl text-center">
            <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-[#2ED3B7] to-[#22C55E] rounded-full flex items-center justify-center">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-[#1C1F2A] text-sm mb-1">
              Quick Learner
            </h3>
            <p className="text-xs text-[#6B7280]">Mastered 50 flashcards</p>
          </div>

          <div className="p-4 bg-gradient-to-br from-[#4A90E2]/10 to-[#4A90E2]/5 border border-[#4A90E2]/20 rounded-xl text-center">
            <div className="w-16 h-16 mx-auto mb-3 bg-gradient-to-br from-[#4A90E2] to-[#6AA8ED] rounded-full flex items-center justify-center">
              <Award className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-[#1C1F2A] text-sm mb-1">
              Exam Master
            </h3>
            <p className="text-xs text-[#6B7280]">Passed 5 practice exams</p>
          </div>
        </div>
      </div>

      {/* Weak Areas Breakdown */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h2 className="text-xl font-bold text-[#1C1F2A] mb-6">
          Areas for Improvement
        </h2>
        <div className="space-y-4">
          {subjectPerformance
            .sort((a, b) => a.score - b.score)
            .slice(0, 3)
            .map((subject) => (
              <div key={subject.subject}>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-[#1C1F2A]">
                    {subject.subject}
                  </span>
                  <span className="text-sm text-[#6B7280]">{subject.score}%</span>
                </div>
                <div className="h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${
                      subject.score >= 80
                        ? "bg-gradient-to-r from-[#22C55E] to-[#2ED3B7]"
                        : subject.score >= 60
                        ? "bg-gradient-to-r from-[#F59E0B] to-[#FBBF24]"
                        : "bg-gradient-to-r from-[#EF4444] to-[#F87171]"
                    }`}
                    style={{ width: `${subject.score}%` }}
                  ></div>
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
