import { useState } from "react";
import { Search, Plus, Filter, FileText, Download, Trash2, Edit, Calendar } from "lucide-react";

const mockNotes = [
  {
    id: 1,
    title: "Integration Techniques",
    subject: "Calculus II",
    date: "April 10, 2026",
    tags: ["Math", "Calculus", "Integration"],
    preview: "Integration by parts, substitution, partial fractions...",
    color: "#7C5CFF",
  },
  {
    id: 2,
    title: "Renaissance Art & Culture",
    subject: "World History",
    date: "April 12, 2026",
    tags: ["History", "Art", "Europe"],
    preview: "The Renaissance period marked a cultural rebirth in Europe...",
    color: "#4A90E2",
  },
  {
    id: 3,
    title: "Organic Chemistry Reactions",
    subject: "Chemistry",
    date: "April 8, 2026",
    tags: ["Chemistry", "Organic", "Reactions"],
    preview: "SN1, SN2, E1, E2 reaction mechanisms and examples...",
    color: "#2ED3B7",
  },
  {
    id: 4,
    title: "Quantum Mechanics Basics",
    subject: "Physics",
    date: "April 5, 2026",
    tags: ["Physics", "Quantum", "Theory"],
    preview: "Wave-particle duality, Heisenberg uncertainty principle...",
    color: "#F59E0B",
  },
  {
    id: 5,
    title: "Linear Algebra Vectors",
    subject: "Mathematics",
    date: "April 14, 2026",
    tags: ["Math", "Linear Algebra", "Vectors"],
    preview: "Vector spaces, linear transformations, eigenvalues...",
    color: "#7C5CFF",
  },
  {
    id: 6,
    title: "World War II Timeline",
    subject: "History",
    date: "April 3, 2026",
    tags: ["History", "WWII", "Timeline"],
    preview: "Major events from 1939-1945 including key battles...",
    color: "#4A90E2",
  },
];

const allTags = Array.from(new Set(mockNotes.flatMap((note) => note.tags)));

export function NotesLibrary() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);

  const filteredNotes = mockNotes.filter((note) => {
    const matchesSearch =
      note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
      note.preview.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesTags =
      selectedTags.length === 0 ||
      selectedTags.some((tag) => note.tags.includes(tag));

    return matchesSearch && matchesTags;
  });

  const toggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-[#1C1F2A] mb-2">Notes Library</h1>
        <p className="text-[#6B7280]">
          All your AI-generated notes in one organized place
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search notes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 bg-[#F7F9FC] border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#4A90E2]"
            />
          </div>

          <div className="flex gap-3">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-6 py-3 bg-white border border-gray-200 rounded-xl hover:bg-gray-50 transition-all"
            >
              <Filter className="w-5 h-5" />
              Filters
              {selectedTags.length > 0 && (
                <span className="ml-1 px-2 py-0.5 bg-[#4A90E2] text-white rounded-full text-xs">
                  {selectedTags.length}
                </span>
              )}
            </button>

            <button className="flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-[#7C5CFF] to-[#9D7FFF] text-white rounded-xl hover:shadow-lg transition-all">
              <Plus className="w-5 h-5" />
              New Note
            </button>
          </div>
        </div>

        {/* Filter Tags */}
        {showFilters && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <p className="text-sm font-medium text-[#1C1F2A] mb-3">Filter by tags:</p>
            <div className="flex flex-wrap gap-2">
              {allTags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                    selectedTags.includes(tag)
                      ? "bg-[#4A90E2] text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
                >
                  {tag}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Notes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredNotes.map((note) => (
          <div
            key={note.id}
            className="bg-white rounded-2xl overflow-hidden shadow-sm border border-gray-100 hover:shadow-lg transition-all cursor-pointer group"
          >
            {/* Colored Header */}
            <div
              className="h-2"
              style={{ backgroundColor: note.color }}
            ></div>

            <div className="p-6">
              {/* Title and Icon */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{ backgroundColor: `${note.color}15` }}
                  >
                    <FileText className="w-5 h-5" style={{ color: note.color }} />
                  </div>
                  <div>
                    <h3 className="font-bold text-[#1C1F2A] group-hover:text-[#4A90E2] transition-colors">
                      {note.title}
                    </h3>
                    <p className="text-sm text-[#6B7280]">{note.subject}</p>
                  </div>
                </div>
              </div>

              {/* Preview */}
              <p className="text-sm text-[#6B7280] mb-4 line-clamp-2">
                {note.preview}
              </p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {note.tags.slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    className="px-2 py-1 bg-gray-100 text-gray-600 rounded-md text-xs"
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Footer */}
              <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                <div className="flex items-center gap-1 text-xs text-[#9CA3AF]">
                  <Calendar className="w-3 h-3" />
                  {note.date}
                </div>

                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <Edit className="w-4 h-4 text-gray-600" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <Download className="w-4 h-4 text-gray-600" />
                  </button>
                  <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                    <Trash2 className="w-4 h-4 text-[#EF4444]" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredNotes.length === 0 && (
        <div className="text-center py-16">
          <FileText className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-[#1C1F2A] mb-2">
            No notes found
          </h3>
          <p className="text-[#6B7280]">
            Try adjusting your search or filters
          </p>
        </div>
      )}
    </div>
  );
}
