import { useState } from "react";
import { Upload, FileText, Clock, CheckCircle2, XCircle, Play } from "lucide-react";

const mockQuizQuestions = [
  {
    id: 1,
    question: "What is the derivative of f(x) = x³ + 2x² - 5x + 1?",
    options: [
      "3x² + 4x - 5",
      "x⁴ + 2x³ - 5x² + x",
      "3x² + 2x - 5",
      "x² + 4x - 5",
    ],
    correctAnswer: 0,
    userAnswer: null,
  },
  {
    id: 2,
    question: "Which theorem states that if f is continuous on [a,b], then f attains a maximum and minimum?",
    options: [
      "Intermediate Value Theorem",
      "Extreme Value Theorem",
      "Mean Value Theorem",
      "Fundamental Theorem of Calculus",
    ],
    correctAnswer: 1,
    userAnswer: null,
  },
  {
    id: 3,
    question: "What is the limit of (sin x)/x as x approaches 0?",
    options: ["0", "1", "∞", "Does not exist"],
    correctAnswer: 1,
    userAnswer: null,
  },
  {
    id: 4,
    question: "The integral of 1/x dx is:",
    options: ["ln|x| + C", "1/x² + C", "x² + C", "e^x + C"],
    correctAnswer: 0,
    userAnswer: null,
  },
];

export function QuizGenerator() {
  const [quizStarted, setQuizStarted] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [questions, setQuestions] = useState(mockQuizQuestions);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(600); // 10 minutes in seconds

  const handleAnswerSelect = (questionId: number, answerIndex: number) => {
    setQuestions((prev) =>
      prev.map((q) =>
        q.id === questionId ? { ...q, userAnswer: answerIndex } : q
      )
    );
  };

  const handleSubmit = () => {
    setQuizCompleted(true);
  };

  const calculateScore = () => {
    const correct = questions.filter((q) => q.userAnswer === q.correctAnswer).length;
    return Math.round((correct / questions.length) * 100);
  };

  if (!quizStarted) {
    return (
      <div className="p-8">
        <h1 className="text-3xl font-bold text-[#1C1F2A] mb-2">
          Quiz Generator
        </h1>
        <p className="text-[#6B7280] mb-8">
          Upload your study materials or select a topic to generate a quiz
        </p>

        <div className="max-w-4xl mx-auto">
          {/* Upload Section */}
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 mb-6">
            <h2 className="text-xl font-bold text-[#1C1F2A] mb-4">
              Upload Study Material
            </h2>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-[#4A90E2] transition-colors cursor-pointer">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="font-semibold text-[#1C1F2A] mb-2">
                Drop files here or click to upload
              </h3>
              <p className="text-sm text-[#6B7280]">
                PDF, DOCX, TXT, or images up to 10MB
              </p>
            </div>
          </div>

          {/* Quick Start Quiz */}
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold text-[#1C1F2A] mb-4">
              Or Try a Sample Quiz
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border border-gray-200 rounded-xl hover:border-[#4A90E2] hover:bg-[#EEF3FB] transition-all cursor-pointer">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-[#7C5CFF]/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-[#7C5CFF]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#1C1F2A]">
                      Calculus II Practice
                    </h3>
                    <p className="text-sm text-[#6B7280] mt-1">
                      12 questions · 15 min
                    </p>
                  </div>
                </div>
              </div>

              <div
                onClick={() => setQuizStarted(true)}
                className="p-4 border-2 border-[#4A90E2] bg-[#4A90E2]/5 rounded-xl hover:bg-[#4A90E2]/10 transition-all cursor-pointer"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 bg-[#4A90E2]/20 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Play className="w-5 h-5 text-[#4A90E2]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-[#1C1F2A]">
                      Calculus Derivatives
                    </h3>
                    <p className="text-sm text-[#6B7280] mt-1">
                      4 questions · 10 min
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (quizCompleted) {
    const score = calculateScore();
    const correct = questions.filter((q) => q.userAnswer === q.correctAnswer).length;

    return (
      <div className="p-8">
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 text-center">
            <div
              className={`w-24 h-24 mx-auto mb-6 rounded-full flex items-center justify-center ${
                score >= 70
                  ? "bg-[#22C55E]/10"
                  : score >= 50
                  ? "bg-[#F59E0B]/10"
                  : "bg-[#EF4444]/10"
              }`}
            >
              <span className="text-4xl font-bold">{score}%</span>
            </div>

            <h1 className="text-3xl font-bold text-[#1C1F2A] mb-2">
              Quiz Complete!
            </h1>
            <p className="text-[#6B7280] mb-8">
              You got {correct} out of {questions.length} questions correct
            </p>

            {/* Results Summary */}
            <div className="space-y-4 mb-8">
              {questions.map((q, index) => (
                <div
                  key={q.id}
                  className={`p-4 rounded-xl border ${
                    q.userAnswer === q.correctAnswer
                      ? "bg-[#22C55E]/5 border-[#22C55E]/20"
                      : "bg-[#EF4444]/5 border-[#EF4444]/20"
                  }`}
                >
                  <div className="flex items-start gap-3 text-left">
                    {q.userAnswer === q.correctAnswer ? (
                      <CheckCircle2 className="w-5 h-5 text-[#22C55E] flex-shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-[#EF4444] flex-shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p className="font-medium text-[#1C1F2A] mb-2">
                        Question {index + 1}: {q.question}
                      </p>
                      <p className="text-sm text-[#6B7280]">
                        Your answer: {q.userAnswer !== null ? q.options[q.userAnswer] : "Not answered"}
                      </p>
                      {q.userAnswer !== q.correctAnswer && (
                        <p className="text-sm text-[#22C55E] mt-1">
                          Correct answer: {q.options[q.correctAnswer]}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-4 justify-center">
              <button
                onClick={() => {
                  setQuizStarted(false);
                  setQuizCompleted(false);
                  setCurrentQuestion(0);
                  setQuestions(mockQuizQuestions);
                }}
                className="px-6 py-3 bg-white border-2 border-[#4A90E2] text-[#4A90E2] rounded-xl hover:bg-[#EEF3FB] transition-all"
              >
                Try Another Quiz
              </button>
              <button className="px-6 py-3 bg-gradient-to-r from-[#4A90E2] to-[#7C5CFF] text-white rounded-xl hover:shadow-lg transition-all">
                Review Answers
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="max-w-3xl mx-auto">
        {/* Quiz Header */}
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-[#1C1F2A]">
                Calculus Derivatives Quiz
              </h1>
              <p className="text-[#6B7280] mt-1">
                Question {currentQuestion + 1} of {questions.length}
              </p>
            </div>
            <div className="flex items-center gap-2 text-[#4A90E2]">
              <Clock className="w-5 h-5" />
              <span className="font-semibold">
                {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, "0")}
              </span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-4 h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#4A90E2] to-[#7C5CFF] transition-all"
              style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Question Card */}
        <div className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100 mb-6">
          <h2 className="text-xl font-semibold text-[#1C1F2A] mb-6">
            {questions[currentQuestion].question}
          </h2>

          <div className="space-y-3">
            {questions[currentQuestion].options.map((option, index) => (
              <button
                key={index}
                onClick={() =>
                  handleAnswerSelect(questions[currentQuestion].id, index)
                }
                className={`w-full p-4 text-left rounded-xl border-2 transition-all ${
                  questions[currentQuestion].userAnswer === index
                    ? "border-[#4A90E2] bg-[#4A90E2]/5"
                    : "border-gray-200 hover:border-[#4A90E2]/50 hover:bg-[#EEF3FB]"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      questions[currentQuestion].userAnswer === index
                        ? "border-[#4A90E2] bg-[#4A90E2]"
                        : "border-gray-300"
                    }`}
                  >
                    {questions[currentQuestion].userAnswer === index && (
                      <div className="w-2 h-2 bg-white rounded-full"></div>
                    )}
                  </div>
                  <span className="font-medium text-[#1C1F2A]">{option}</span>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex justify-between">
          <button
            onClick={() => setCurrentQuestion((prev) => Math.max(0, prev - 1))}
            disabled={currentQuestion === 0}
            className="px-6 py-3 bg-white border border-gray-200 text-[#1C1F2A] rounded-xl hover:bg-gray-50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Previous
          </button>

          {currentQuestion === questions.length - 1 ? (
            <button
              onClick={handleSubmit}
              className="px-6 py-3 bg-gradient-to-r from-[#22C55E] to-[#2ED3B7] text-white rounded-xl hover:shadow-lg transition-all"
            >
              Submit Quiz
            </button>
          ) : (
            <button
              onClick={() =>
                setCurrentQuestion((prev) => Math.min(questions.length - 1, prev + 1))
              }
              className="px-6 py-3 bg-gradient-to-r from-[#4A90E2] to-[#7C5CFF] text-white rounded-xl hover:shadow-lg transition-all"
            >
              Next Question
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
