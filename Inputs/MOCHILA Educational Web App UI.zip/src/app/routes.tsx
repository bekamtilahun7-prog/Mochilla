import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Dashboard } from "./pages/Dashboard";
import { AskMochila } from "./pages/AskMochila";
import { QuizGenerator } from "./pages/QuizGenerator";
import { Flashcards } from "./pages/Flashcards";
import { ExamMode } from "./pages/ExamMode";
import { NotesLibrary } from "./pages/NotesLibrary";
import { ProgressTracker } from "./pages/ProgressTracker";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Dashboard },
      { path: "ask-mochila", Component: AskMochila },
      { path: "quiz", Component: QuizGenerator },
      { path: "flashcards", Component: Flashcards },
      { path: "exam", Component: ExamMode },
      { path: "notes", Component: NotesLibrary },
      { path: "progress", Component: ProgressTracker },
    ],
  },
]);
